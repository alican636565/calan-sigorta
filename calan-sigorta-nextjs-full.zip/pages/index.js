import React from "react";

export default function Home() {
  return (
    <div style={{fontFamily: "sans-serif", padding: "2rem"}}>
      <h1>CALAN SİGORTA</h1>
      <p>Değerlerinize Değer Katar...</p>
      <img src="/logo.png" alt="Calan Sigorta Logo" width="120" />
    </div>
  );
}
